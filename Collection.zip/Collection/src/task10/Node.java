package task10;

public class Node {
	int data;
    Node left, right;
     
    Node(int d) {
        data = d;
        left = right = null;
    }
}
